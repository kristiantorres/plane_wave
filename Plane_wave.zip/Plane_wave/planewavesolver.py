from devito import Eq, Operator, TimeFunction, solve
from examples.seismic import PointSource, Receiver
from examples.seismic.acoustic.operators import laplacian, freesurface
from examples.seismic.acoustic.wavesolver import AcousticWaveSolver
from devito.tools import memoized_meth

def pw_iso_stencil(field, model, kernel, **kwargs):
    """
    Stencil for the acoustic isotropic wave-equation:
    u.dt2 - H + damp*u.dt = 0.

    Parameters
    ----------
    field : TimeFunction
        The computed solution.
    model : Model
        Physical model.
    kernel : str, optional
        Type of discretization, 'OT2' or 'OT4'.
    q : TimeFunction, Function or float
        Full-space/time source of the wave-equation.
    forward : bool, optional
        Whether to propagate forward (True) or backward (False) in time.
    """
    # Forward or backward
    forward = kwargs.get('forward', True)
    # Define time step to be updated
    unext = field.forward if forward else field.backward
    udt = field.dt if forward else field.dt.T
    # Get the spacial FD
    lap = laplacian(field, model, kernel)
    # Get source
    q = kwargs.get('q', 0)
    # Define PDE and update rule
    eq_time = solve(model.m * field.dt2 - lap - q + model.damp * udt, unext)

    # Apply boundary conditions to simulate plane wave
    x, z = model.grid.dimensions
    t = model.grid.stepping_dim
    nbl = model.nbl
    nx, nz = model.shape
    bc_left1 = Eq(field[t+1, nbl, z], field[t+1, nbl+1, z])
    bc_left2 = Eq(field[t+1, nbl+1, z], field[t+1, nbl+2, z])
    bc_left3 = Eq(field[t+1, x, nbl], field[t+1, x, nbl+1])
    bc_left4 = Eq(field[t+1, x, nbl+1], field[t+1, x, nbl+2])
    bc_right1 = Eq(field[t+1, nbl+nx-2, z], field[t+1, nbl+nx-3, z])
    bc_right2 = Eq(field[t+1, nbl+nx-1, z], field[t+1, nbl+nx-2, z])
    bc_right3 = Eq(field[t+1, x, nbl+nz-2], field[t+1, x, nbl+nz-3])
    bc_right4 = Eq(field[t+1, x, nbl+nz-1], field[t+1, x, nbl+nz-2])

    # Time-stepping stencil.
    eqns = [Eq(unext, eq_time, subdomain=model.grid.subdomains['physdomain'])]
    #eqns += [bc_left1, bc_left2, bc_right1, bc_right2]
    
    # Add free surface TODO
    # if model.fs:
    #     eqns.append(freesurface(model, Eq(unext, eq_time)))
    return eqns

def PWForwardOperator(model, geometry, space_order=4,
                    save=False, kernel='OT2', **kwargs):
    """
    Construct a forward modelling plane operator in an acoustic medium.

    Parameters
    ----------
    model : Model
        Object containing the physical parameters.
    geometry : AcquisitionGeometry
        Geometry object that contains the source (SparseTimeFunction) and
        receivers (SparseTimeFunction) and their position.
    space_order : int, optional
        Space discretization order.
    save : int or Buffer, optional
        Saving flag, True saves all time steps. False saves three timesteps.
        Defaults to False.
    kernel : str, optional
        Type of discretization, 'OT2' or 'OT4'.
    """
    m = model.m

    # Create symbols for forward wavefield, source and receivers
    u = TimeFunction(name='u', grid=model.grid,
                        save=geometry.nt if save else None,
                        time_order=2, space_order=space_order)
    src = PointSource(name='src', grid=geometry.grid, time_range=geometry.time_axis,
                        npoint=geometry.nsrc)

    rec = Receiver(name='rec', grid=geometry.grid, time_range=geometry.time_axis,
                    npoint=geometry.nrec)

    s = model.grid.stepping_dim.spacing

    eqn = pw_iso_stencil(u, model, kernel)

    # Construct expression to inject source values
    src_term = src.inject(field=u.forward, expr=(src*s**2)/m)

    # Create interpolation expression for receivers
    rec_term = rec.interpolate(expr=u)
    # Substitute spacing terms to reduce flops
    return Operator(eqn + src_term + rec_term, subs=model.spacing_map,
                    name='Forward', **kwargs)

class PlaneWaveSolver(AcousticWaveSolver):
    @memoized_meth
    def pwop_fwd(self, save=None):
        """Cached operator for forward runs with buffered wavefield"""
        op = PWForwardOperator(self.model, save=save, geometry=self.geometry,
                                kernel=self.kernel, space_order=self.space_order,
                               **self._kwargs)
        # print(op.ccode)
        return op
    
    def forward(self, src=None, rec=None, u=None, vp=None, save=None, **kwargs):
        """
        Forward modelling function that creates the necessary
        data objects for running a plane wave forward modelling operator.

        Parameters
        ----------
        src : SparseTimeFunction or array_like, optional
            Time series data for the injected source term.
        rec : SparseTimeFunction or array_like, optional
            The interpolated receiver data.
        u : TimeFunction, optional
            Stores the computed wavefield.
        vp : Function or float, optional
            The time-constant velocity.
        save : bool, optional
            Whether or not to save the entire (unrolled) wavefield.

        Returns
        -------
        Receiver, wavefield and performance summary
        """
        # Source term is read-only, so re-use the default
        src = src or self.geometry.src
        # Create a new receiver object to store the result
        rec = rec or self.geometry.rec

        # Create the forward wavefield if not provided
        u = u or TimeFunction(name='u', grid=self.model.grid,
                            save=self.geometry.nt if save else None,
                            time_order=2, space_order=self.space_order)

        # Pick vp from model unless explicitly provided
        vp = vp or self.model.vp

        # Execute operator and return wavefield and receiver data
        summary = self.pwop_fwd(save).apply(src=src, rec=rec, u=u, vp=vp,
                                        dt=kwargs.pop('dt', self.dt), **kwargs)
        return rec, u, summary
    